<html>
    <head>
        <title>
            Shop
        </title>
    </head>

    <body>
        <table>
            <th>
                <tr>
                    Williams
                </tr>
                <tr>
                    <p><img src="bILDER_SRC/HP.jpg" ></p>
                </tr>
                <tr>
                    2000₺
                </tr>
            </th>
            <th>
                <tr>
                </tr>
            </th>
        </table>
    </body>
</html>